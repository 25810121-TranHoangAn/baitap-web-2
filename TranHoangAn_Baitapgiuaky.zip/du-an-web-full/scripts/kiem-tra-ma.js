// Kiem tra cau truc va cac quy tac can thiet ma khong can ket noi Neon.
const fs = require('fs');
const path = require('path');
const goc = path.resolve(__dirname, '..');
const batBuoc = [
  'app.js', 'package.json', '.env.example', '.gitignore',
  'database/tao-bang.sql', 'database/khoi-tao.js',
  'models/db.js', 'models/nguoiDung.js', 'models/danhMuc.js', 'models/baiViet.js',
  'controllers/xacThucController.js', 'controllers/trangChuController.js',
  'controllers/baiVietController.js', 'controllers/quanLyController.js',
  'routes/cong-khai.js', 'routes/xac-thuc.js', 'routes/quan-ly.js',
  'middlewares/yeuCauDangNhap.js', 'views/partials/dau-trang.ejs',
  'views/partials/chan-trang.ejs', 'views/partials/the-tin.ejs',
  'views/trang-chu.ejs', 'views/danh-muc.ejs', 'views/bai-viet.ejs',
  'views/dang-nhap.ejs', 'views/quan-ly.ejs', 'views/bai-form.ejs',
  'views/404.ejs', 'views/loi.ejs', 'public/css/style.css'
];
const loi = [];
for (const ten of batBuoc) {
  if (!fs.existsSync(path.join(goc, ten))) loi.push('Thiếu file: ' + ten);
}
const sql = fs.readFileSync(path.join(goc, 'database/tao-bang.sql'), 'utf8');
for (const bang of ['nguoi_dung', 'danh_muc', 'bai_viet']) {
  if (!sql.includes('CREATE TABLE ' + bang)) loi.push('Thiếu bảng SQL: ' + bang);
}
for (const token of ['PRIMARY KEY', 'REFERENCES', 'CHECK', 'CREATE INDEX']) {
  if (!sql.includes(token)) loi.push('Thiếu ràng buộc/chỉ mục SQL: ' + token);
}
const model = fs.readFileSync(path.join(goc, 'models/baiViet.js'), 'utf8');
if (!model.includes('WHERE id = $1')) loi.push('Không thấy truy vấn xoa theo id có tham số.');
if (!model.includes('WHERE id = $11')) loi.push('Không thấy truy vấn sua có WHERE theo id.');
const ignore = fs.readFileSync(path.join(goc, '.gitignore'), 'utf8');
if (!ignore.split(/\r?\n/).includes('.env')) loi.push('.gitignore chưa loại trừ .env.');
if (fs.existsSync(path.join(goc, '.env'))) loi.push('Không đóng gói file .env có thể chứa bí mật.');
if (fs.existsSync(path.join(goc, 'node_modules'))) loi.push('Không đóng gói node_modules.');
if (loi.length) {
  console.error('KIỂM TRA THẤT BẠI:\n- ' + loi.join('\n- '));
  process.exit(1);
}
console.log('Kiểm tra cấu trúc đạt: ' + batBuoc.length + ' file bắt buộc, 3 bảng, ràng buộc SQL, .gitignore và tệp bí mật.');
console.log('Lưu ý: kiểm tra này không thay thế kiểm thử kết nối Neon thực tế.');
