// Model duy nhat truy cap bang nguoi_dung.
const bcrypt = require('bcryptjs');
const db = require('./db');

async function timTheoTenDangNhap(tenDangNhap) {
  const kq = await db.query(
    'SELECT id, ten_dang_nhap, mat_khau_bam, ho_ten, vai_tro FROM nguoi_dung WHERE ten_dang_nhap = $1',
    [tenDangNhap]
  );
  return kq.rows[0] || null;
}

async function xacThuc(tenDangNhap, matKhau) {
  const nguoi = await timTheoTenDangNhap(tenDangNhap);
  if (!nguoi) return null;
  const dung = await bcrypt.compare(matKhau, nguoi.mat_khau_bam);
  if (!dung) return null;
  // Chi tra thong tin can thiet, khong tra mat khau hoac ban bam.
  return {
    id: nguoi.id,
    tenDangNhap: nguoi.ten_dang_nhap,
    hoTen: nguoi.ho_ten,
    vaiTro: nguoi.vai_tro
  };
}

module.exports = { timTheoTenDangNhap, xacThuc };
