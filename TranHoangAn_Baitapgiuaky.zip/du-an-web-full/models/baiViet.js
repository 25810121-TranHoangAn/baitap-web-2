// Model bai_viet: moi cau SQL truy van bai viet trong ung dung nam tai day.
const db = require('./db');
const CHON_BAI = `
  SELECT b.id, b.tieu_de, b.tom_tat, b.noi_dung, b.anh_dai_dien, b.ten_tap_chi,
         b.tieu_de_goc, b.lien_ket_goc, b.nam_xuat_ban, b.trang_thai, b.luot_xem,
         b.ngay_dang, b.id_danh_muc, b.id_nguoi_tao,
         d.ten AS ten_danh_muc, d.duong_dan AS duong_dan_danh_muc
  FROM bai_viet b
  JOIN danh_muc d ON d.id = b.id_danh_muc`;

async function moiNhat(gioiHan) {
  const kq = await db.query(
    CHON_BAI + " WHERE b.trang_thai = 'da_dang' ORDER BY b.ngay_dang DESC, b.id DESC LIMIT $1",
    [gioiHan]
  );
  return kq.rows;
}

async function docNhieu(gioiHan) {
  const kq = await db.query(
    CHON_BAI + " WHERE b.trang_thai = 'da_dang' ORDER BY b.luot_xem DESC, b.id DESC LIMIT $1",
    [gioiHan]
  );
  return kq.rows;
}

async function theoDanhMuc(idDanhMuc) {
  const kq = await db.query(
    CHON_BAI + " WHERE b.trang_thai = 'da_dang' AND b.id_danh_muc = $1 ORDER BY b.ngay_dang DESC, b.id DESC",
    [idDanhMuc]
  );
  return kq.rows;
}

async function timKiem(tuKhoa) {
  const kq = await db.query(
    CHON_BAI + " WHERE b.trang_thai = 'da_dang' AND (b.tieu_de ILIKE $1 OR b.tom_tat ILIKE $1) ORDER BY b.ngay_dang DESC, b.id DESC",
    ['%' + tuKhoa + '%']
  );
  return kq.rows;
}

async function timTheoId(id) {
  const kq = await db.query(CHON_BAI + ' WHERE b.id = $1', [id]);
  return kq.rows[0] || null;
}

async function lienQuan(idDanhMuc, idLoaiTru, gioiHan) {
  const kq = await db.query(
    CHON_BAI + " WHERE b.trang_thai = 'da_dang' AND b.id_danh_muc = $1 AND b.id <> $2 ORDER BY b.ngay_dang DESC, b.id DESC LIMIT $3",
    [idDanhMuc, idLoaiTru, gioiHan]
  );
  return kq.rows;
}

async function tangLuotXem(id) {
  await db.query('UPDATE bai_viet SET luot_xem = luot_xem + 1 WHERE id = $1', [id]);
}

async function tatCaChoQuanLy() {
  const kq = await db.query(CHON_BAI + ' ORDER BY b.id DESC');
  return kq.rows;
}

async function thongKe() {
  const kq = await db.query(
    `SELECT COUNT(*)::int AS tong,
            COUNT(*) FILTER (WHERE trang_thai = 'nhap')::int AS nhap
     FROM bai_viet`
  );
  return kq.rows[0];
}

async function them(d) {
  const kq = await db.query(
    `INSERT INTO bai_viet
      (tieu_de, tom_tat, noi_dung, anh_dai_dien, ten_tap_chi, tieu_de_goc, lien_ket_goc,
       nam_xuat_ban, trang_thai, id_danh_muc, id_nguoi_tao)
     VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11)
     RETURNING id`,
    [d.tieuDe, d.tomTat, d.noiDung, d.anhDaiDien, d.tenTapChi, d.tieuDeGoc,
      d.lienKetGoc, d.namXuatBan, d.trangThai, d.idDanhMuc, d.idNguoiTao]
  );
  return kq.rows[0].id;
}

async function sua(id, d) {
  const kq = await db.query(
    `UPDATE bai_viet
     SET tieu_de = $1, tom_tat = $2, noi_dung = $3, anh_dai_dien = $4,
         ten_tap_chi = $5, tieu_de_goc = $6, lien_ket_goc = $7, nam_xuat_ban = $8,
         trang_thai = $9, id_danh_muc = $10
     WHERE id = $11`,
    [d.tieuDe, d.tomTat, d.noiDung, d.anhDaiDien, d.tenTapChi, d.tieuDeGoc,
      d.lienKetGoc, d.namXuatBan, d.trangThai, d.idDanhMuc, id]
  );
  return kq.rowCount;
}

async function xoa(id) {
  const kq = await db.query('DELETE FROM bai_viet WHERE id = $1', [id]);
  return kq.rowCount;
}

module.exports = {
  moiNhat, docNhieu, theoDanhMuc, timKiem, timTheoId, lienQuan, tangLuotXem,
  tatCaChoQuanLy, thongKe, them, sua, xoa
};
