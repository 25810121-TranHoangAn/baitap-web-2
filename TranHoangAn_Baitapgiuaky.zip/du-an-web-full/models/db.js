// models/db.js: mot Pool dung chung cho cac Model.
const { Pool } = require('pg');

if (!process.env.DATABASE_URL) {
  throw new Error('THIEU DATABASE_URL. Kiem tra file .env.');
}

const pool = new Pool({ connectionString: process.env.DATABASE_URL });
pool.on('error', (loi) => {
  console.error('Loi ket noi co so du lieu:', loi.message);
});

module.exports = pool;
