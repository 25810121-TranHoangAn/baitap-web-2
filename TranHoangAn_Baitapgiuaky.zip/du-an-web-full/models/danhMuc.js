// Model cua bang danh_muc.
const db = require('./db');

async function tatCa() {
  const kq = await db.query('SELECT id, ten, duong_dan FROM danh_muc ORDER BY id');
  return kq.rows;
}

async function timTheoDuongDan(duongDan) {
  const kq = await db.query(
    'SELECT id, ten, duong_dan FROM danh_muc WHERE duong_dan = $1',
    [duongDan]
  );
  return kq.rows[0] || null;
}

async function demBai() {
  const kq = await db.query(
    `SELECT d.id, d.ten, d.duong_dan, COUNT(b.id)::int AS so_bai
     FROM danh_muc d
     LEFT JOIN bai_viet b ON b.id_danh_muc = d.id
     GROUP BY d.id
     ORDER BY d.id`
  );
  return kq.rows;
}

module.exports = { tatCa, timTheoDuongDan, demBai };
