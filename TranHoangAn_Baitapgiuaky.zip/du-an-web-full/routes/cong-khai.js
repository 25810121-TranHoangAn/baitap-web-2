// Cac route cong khai: trang chu, tim kiem, danh muc va bai viet.
const express = require('express');
const router = express.Router();
const trangChu = require('../controllers/trangChuController');
const baiViet = require('../controllers/baiVietController');

router.get('/', trangChu.trangChu);
router.get('/tim-kiem', trangChu.timKiem);
router.get('/danh-muc/:duongDan', baiViet.theoDanhMuc);
router.get('/bai-viet/:id', baiViet.chiTiet);

module.exports = router;
