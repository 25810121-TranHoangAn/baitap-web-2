// Tat ca route quan ly deu duoc bao ve boi middleware o dau Router.
const express = require('express');
const router = express.Router();
const yeuCauDangNhap = require('../middlewares/yeuCauDangNhap');
const quanLy = require('../controllers/quanLyController');

router.use(yeuCauDangNhap);
router.get('/', quanLy.danhSach);
router.get('/them', quanLy.hienThem);
router.post('/them', quanLy.them);
router.get('/:id/sua', quanLy.hienSua);
router.post('/:id/sua', quanLy.sua);
router.post('/:id/xoa', quanLy.xoa);

module.exports = router;
