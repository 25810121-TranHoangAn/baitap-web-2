// Route dang nhap, dang xuat.
const express = require('express');
const router = express.Router();
const xacThuc = require('../controllers/xacThucController');

router.get('/dang-nhap', xacThuc.hienDangNhap);
router.post('/dang-nhap', xacThuc.xuLyDangNhap);
router.post('/dang-xuat', xacThuc.dangXuat);

module.exports = router;
