const NguoiDung = require('../models/nguoiDung');

function hienDangNhap(req, res) {
  res.render('dang-nhap', { tieuDe: 'Đăng nhập', loi: null, tenDangNhap: '' });
}

async function xuLyDangNhap(req, res) {
  const duLieu = req.body || {};
  const tenDangNhap = String(duLieu.tenDangNhap || '').trim();
  const matKhau = String(duLieu.matKhau || '');

  if (tenDangNhap === '' || matKhau === '') {
    return res.status(400).render('dang-nhap', {
      tieuDe: 'Đăng nhập',
      loi: 'Vui lòng nhập đầy đủ tên đăng nhập và mật khẩu.',
      tenDangNhap
    });
  }

  const nguoiDung = await NguoiDung.xacThuc(tenDangNhap, matKhau);
  if (!nguoiDung) {
    return res.status(401).render('dang-nhap', {
      tieuDe: 'Đăng nhập',
      loi: 'Sai tên đăng nhập hoặc mật khẩu.',
      tenDangNhap
    });
  }

  // Khong bao gio luu mat khau hay ban bam vao session.
  req.session.regenerate((loi) => {
    if (loi) return res.status(500).render('loi', { tieuDe: 'Có lỗi xảy ra', muc: '' });
    req.session.nguoiDung = nguoiDung;
    req.session.save((loiLuu) => {
      if (loiLuu) return res.status(500).render('loi', { tieuDe: 'Có lỗi xảy ra', muc: '' });
      res.redirect('/quan-ly');
    });
  });
}

function dangXuat(req, res, next) {
  if (!req.session) return res.redirect('/');
  req.session.destroy((loi) => {
    if (loi) return next(loi);
    res.clearCookie('connect.sid');
    res.redirect('/');
  });
}

module.exports = { hienDangNhap, xuLyDangNhap, dangXuat };
