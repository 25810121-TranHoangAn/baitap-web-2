const BaiViet = require('../models/baiViet');
const DanhMuc = require('../models/danhMuc');

async function theoDanhMuc(req, res, next) {
  const danhMuc = await DanhMuc.timTheoDuongDan(req.params.duongDan);
  if (!danhMuc) return next();
  const danhSach = await BaiViet.theoDanhMuc(danhMuc.id);
  res.render('danh-muc', {
    tieuDe: danhMuc.ten,
    muc: danhMuc.duong_dan,
    tenMuc: danhMuc.ten,
    danhSach,
    tuKhoa: ''
  });
}

function tachDoan(noiDung) {
  return noiDung.split(/\r?\n\s*\r?\n/).map((doan) => {
    const chu = doan.trim();
    return chu.startsWith('## ')
      ? { loai: 'tieu-de', chu: chu.slice(3) }
      : { loai: 'doan', chu };
  }).filter((d) => d.chu !== '');
}

async function chiTiet(req, res, next) {
  const id = Number(req.params.id);
  if (!Number.isInteger(id) || id < 1) return next();
  const bai = await BaiViet.timTheoId(id);
  if (!bai || (bai.trang_thai !== 'da_dang' && !req.session.nguoiDung)) return next();
  if (bai.trang_thai === 'da_dang') {
    await BaiViet.tangLuotXem(id);
    bai.luot_xem += 1; // Dong bo so hien thi voi so luot sau lan mo bai nay.
  }
  const lienQuan = await BaiViet.lienQuan(bai.id_danh_muc, bai.id, 3);
  res.render('bai-viet', {
    tieuDe: bai.tieu_de,
    muc: bai.duong_dan_danh_muc,
    bai,
    cacDoan: tachDoan(bai.noi_dung),
    lienQuan
  });
}

module.exports = { theoDanhMuc, chiTiet };
