const BaiViet = require('../models/baiViet');
const DanhMuc = require('../models/danhMuc');

function docBieuMau(body) {
  const b = body || {};
  const cat = (chu) => String(chu || '').trim();
  const du = {
    tieuDe: cat(b.tieuDe),
    tomTat: cat(b.tomTat),
    noiDung: cat(b.noiDung),
    tenTapChi: cat(b.tenTapChi),
    tieuDeGoc: cat(b.tieuDeGoc) || null,
    lienKetGoc: cat(b.lienKetGoc) || null,
    anhDaiDien: cat(b.anhDaiDien) || null,
    namXuatBan: cat(b.namXuatBan) === '' ? null : Number(b.namXuatBan),
    idDanhMuc: Number(b.idDanhMuc),
    trangThai: cat(b.trangThai)
  };
  const loi = [];
  if (du.tieuDe === '' || du.tieuDe.length > 255) loi.push('Tiêu đề bắt buộc, tối đa 255 ký tự.');
  if (du.tomTat === '') loi.push('Vui lòng nhập tóm tắt.');
  if (du.noiDung === '') loi.push('Vui lòng nhập nội dung.');
  if (du.tenTapChi === '' || du.tenTapChi.length > 150) loi.push('Tên tạp chí bắt buộc, tối đa 150 ký tự.');
  if (du.tieuDeGoc !== null && du.tieuDeGoc.length > 500) loi.push('Tiêu đề gốc tối đa 500 ký tự.');
  if (du.lienKetGoc !== null && du.lienKetGoc.length > 500) loi.push('Liên kết bài gốc tối đa 500 ký tự.');
  if (du.anhDaiDien !== null && du.anhDaiDien.length > 500) loi.push('URL ảnh đại diện tối đa 500 ký tự.');
  if (!Number.isInteger(du.idDanhMuc) || du.idDanhMuc < 1) loi.push('Vui lòng chọn danh mục.');
  if (!['nhap', 'da_dang'].includes(du.trangThai)) loi.push('Trạng thái không hợp lệ.');
  if (du.namXuatBan !== null && (!Number.isInteger(du.namXuatBan) || du.namXuatBan < 1900 || du.namXuatBan > 2100)) {
    loi.push('Năm xuất bản phải từ 1900 đến 2100.');
  }
  if (du.lienKetGoc !== null && !/^https?:\/\//i.test(du.lienKetGoc)) {
    loi.push('Liên kết bài gốc phải bắt đầu bằng http:// hoặc https://');
  }
  if (du.anhDaiDien !== null && !/^https?:\/\//i.test(du.anhDaiDien)) {
    loi.push('Ảnh đại diện phải là địa chỉ bắt đầu bằng http:// hoặc https://');
  }
  return { du, loi };
}

async function hienBieuMau(res, trang) {
  const danhMuc = await DanhMuc.tatCa();
  return res.status(trang.maLoi || 200).render('bai-form', {
    tieuDe: trang.tieuDe,
    muc: '',
    danhMuc,
    hanhDong: trang.hanhDong,
    nutLuu: trang.nutLuu,
    du: trang.du,
    loi: trang.loi || []
  });
}

const DU_TRONG = {
  tieuDe: '', tomTat: '', noiDung: '', tenTapChi: '', tieuDeGoc: '', lienKetGoc: '',
  anhDaiDien: '', namXuatBan: '', idDanhMuc: '', trangThai: 'nhap'
};

async function danhSach(req, res) {
  const [baiViet, thongKe, danhMuc] = await Promise.all([
    BaiViet.tatCaChoQuanLy(), BaiViet.thongKe(), DanhMuc.demBai()
  ]);
  res.render('quan-ly', { tieuDe: 'Bảng quản lý', muc: '', baiViet, thongKe, danhMuc });
}

async function hienThem(req, res) {
  await hienBieuMau(res, {
    tieuDe: 'Thêm bài mới', hanhDong: '/quan-ly/them', nutLuu: 'Lưu bài', du: DU_TRONG
  });
}

async function them(req, res) {
  const { du, loi } = docBieuMau(req.body);
  if (loi.length) {
    return hienBieuMau(res, {
      tieuDe: 'Thêm bài mới', hanhDong: '/quan-ly/them', nutLuu: 'Lưu bài', du, loi, maLoi: 400
    });
  }
  du.idNguoiTao = req.session.nguoiDung.id;
  try {
    await BaiViet.them(du);
  } catch (e) {
    if (e.code !== '23503') throw e;
    return hienBieuMau(res, {
      tieuDe: 'Thêm bài mới', hanhDong: '/quan-ly/them', nutLuu: 'Lưu bài', du,
      loi: ['Danh mục không tồn tại.'], maLoi: 400
    });
  }
  res.redirect('/quan-ly');
}

function layId(req) {
  const id = Number(req.params.id);
  return Number.isInteger(id) && id > 0 ? id : null;
}

async function hienSua(req, res, next) {
  const id = layId(req);
  if (id === null) return next();
  const bai = await BaiViet.timTheoId(id);
  if (!bai) return next();
  const du = {
    tieuDe: bai.tieu_de, tomTat: bai.tom_tat, noiDung: bai.noi_dung, tenTapChi: bai.ten_tap_chi,
    tieuDeGoc: bai.tieu_de_goc || '', lienKetGoc: bai.lien_ket_goc || '', anhDaiDien: bai.anh_dai_dien || '',
    namXuatBan: bai.nam_xuat_ban === null ? '' : bai.nam_xuat_ban,
    idDanhMuc: bai.id_danh_muc, trangThai: bai.trang_thai
  };
  await hienBieuMau(res, {
    tieuDe: 'Sửa bài viết', hanhDong: '/quan-ly/' + id + '/sua', nutLuu: 'Lưu thay đổi', du
  });
}

async function sua(req, res, next) {
  const id = layId(req);
  if (id === null) return next();
  const { du, loi } = docBieuMau(req.body);
  if (loi.length) {
    return hienBieuMau(res, {
      tieuDe: 'Sửa bài viết', hanhDong: '/quan-ly/' + id + '/sua', nutLuu: 'Lưu thay đổi', du, loi, maLoi: 400
    });
  }
  let soDong;
  try {
    soDong = await BaiViet.sua(id, du);
  } catch (e) {
    if (e.code !== '23503') throw e;
    return hienBieuMau(res, {
      tieuDe: 'Sửa bài viết', hanhDong: '/quan-ly/' + id + '/sua', nutLuu: 'Lưu thay đổi', du,
      loi: ['Danh mục không tồn tại.'], maLoi: 400
    });
  }
  if (soDong === 0) return next();
  res.redirect('/quan-ly');
}

async function xoa(req, res, next) {
  const id = layId(req);
  if (id === null) return next();
  const soDong = await BaiViet.xoa(id);
  if (soDong === 0) return next();
  res.redirect('/quan-ly');
}

module.exports = { danhSach, hienThem, them, hienSua, sua, xoa };
