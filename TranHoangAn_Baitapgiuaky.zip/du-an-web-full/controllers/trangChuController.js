const BaiViet = require('../models/baiViet');

async function trangChu(req, res) {
  const moi = await BaiViet.moiNhat(10);
  const docNhieu = await BaiViet.docNhieu(5);
  res.render('trang-chu', {
    tieuDe: 'Tin tức y khoa, dinh dưỡng, sức khoẻ',
    muc: 'trang-chu',
    noiBat: moi[0] || null,
    tinMoi: moi.slice(1),
    docNhieu
  });
}

async function timKiem(req, res) {
  const tuKhoa = String(req.query.q || '').trim().slice(0, 100);
  const danhSach = tuKhoa === '' ? [] : await BaiViet.timKiem(tuKhoa);
  res.render('danh-muc', {
    tieuDe: 'Tìm kiếm',
    muc: '',
    tenMuc: tuKhoa === '' ? 'Tìm kiếm' : 'Kết quả cho “' + tuKhoa + '”',
    danhSach,
    tuKhoa
  });
}

module.exports = { trangChu, timKiem };
