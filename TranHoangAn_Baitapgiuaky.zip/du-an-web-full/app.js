// app.js: diem khoi dong, chi cau hinh va noi cac thanh phan MVC.
require('dotenv').config();

const express = require('express');
const path = require('path');
const session = require('express-session');
const DanhMuc = require('./models/danhMuc');
const congKhaiRoutes = require('./routes/cong-khai');
const xacThucRoutes = require('./routes/xac-thuc');
const quanLyRoutes = require('./routes/quan-ly');

if (!process.env.DATABASE_URL) {
  throw new Error('THIEU DATABASE_URL. Hay tao file .env tu .env.example va dien chuoi ket noi Neon.');
}
if (!process.env.SESSION_SECRET) {
  throw new Error('THIEU SESSION_SECRET. Hay them chuoi bi mat vao file .env.');
}

const app = express();
const PORT = process.env.PORT || 3000;
if (process.env.NODE_ENV === 'production') app.set('trust proxy', 1);
app.set('view engine', 'ejs');
app.set('views', path.join(__dirname, 'views'));

// Cac ham tien ich dung trong moi View.
app.locals.dinhDangNgay = (ngay) => {
  const d = new Date(ngay);
  return String(d.getDate()).padStart(2, '0') + '/' +
    String(d.getMonth() + 1).padStart(2, '0') + '/' + d.getFullYear();
};
app.locals.isoNgay = (ngay) => new Date(ngay).toISOString().slice(0, 10);
app.locals.anhBai = (bai) => bai.anh_dai_dien || 'https://placehold.co/800x600?text=MedDigest+VN';

app.use(express.static(path.join(__dirname, 'public')));
app.use(express.urlencoded({ extended: false, limit: '1mb' }));
app.use(session({
  secret: process.env.SESSION_SECRET,
  resave: false,
  saveUninitialized: false,
  cookie: {
    maxAge: 60 * 60 * 1000,
    httpOnly: true,
    sameSite: 'lax',
    secure: process.env.NODE_ENV === 'production'
  }
}));

// Moi View duoc biet nguoi dung va danh muc menu. Dat sau session, truoc cac route.
app.use(async (req, res, next) => {
  res.locals.nguoiDung = req.session.nguoiDung || null;
  res.locals.danhMucMenu = await DanhMuc.tatCa();
  next();
});

app.use('/', congKhaiRoutes);
app.use('/', xacThucRoutes);
app.use('/quan-ly', quanLyRoutes);

// 404 phai dung sau tat ca route.
app.use((req, res) => {
  res.status(404).render('404', {
    tieuDe: 'Không tìm thấy trang',
    muc: '',
    duongDan: req.originalUrl
  });
});

// 500: ghi chi tiet trong log; khong gui SQL hay stack trace cho nguoi dung.
app.use((loi, req, res, next) => {
  console.error('LOI MAY CHU:', loi);
  if (res.headersSent) return next(loi);
  res.status(500).render('loi', { tieuDe: 'Có lỗi xảy ra', muc: '' });
});

app.listen(PORT, () => {
  console.log(`Máy chủ đang chạy tại http://localhost:${PORT}`);
});
