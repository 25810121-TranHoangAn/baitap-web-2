-- MedDigest VN: thiet ke CSDL theo tai lieu huong dan.
-- CANH BAO: script nay xoa cac bang cu va toan bo du lieu trong do.
DROP TABLE IF EXISTS bai_viet;
DROP TABLE IF EXISTS danh_muc;
DROP TABLE IF EXISTS nguoi_dung;

CREATE TABLE nguoi_dung (
  id SERIAL PRIMARY KEY,
  ten_dang_nhap VARCHAR(50) NOT NULL UNIQUE,
  mat_khau_bam VARCHAR(100) NOT NULL,
  ho_ten VARCHAR(100) NOT NULL,
  vai_tro VARCHAR(20) NOT NULL DEFAULT 'bien_tap_vien'
    CHECK (vai_tro IN ('quan_tri', 'bien_tap_vien')),
  ngay_tao TIMESTAMP NOT NULL DEFAULT NOW()
);

CREATE TABLE danh_muc (
  id SERIAL PRIMARY KEY,
  ten VARCHAR(50) NOT NULL UNIQUE,
  duong_dan VARCHAR(50) NOT NULL UNIQUE
);

CREATE TABLE bai_viet (
  id SERIAL PRIMARY KEY,
  tieu_de VARCHAR(255) NOT NULL,
  tom_tat TEXT NOT NULL,
  noi_dung TEXT NOT NULL,
  anh_dai_dien VARCHAR(500),
  ten_tap_chi VARCHAR(150) NOT NULL,
  tieu_de_goc VARCHAR(500),
  lien_ket_goc VARCHAR(500),
  nam_xuat_ban INTEGER CHECK (nam_xuat_ban BETWEEN 1900 AND 2100),
  trang_thai VARCHAR(20) NOT NULL DEFAULT 'nhap'
    CHECK (trang_thai IN ('nhap', 'da_dang')),
  luot_xem INTEGER NOT NULL DEFAULT 0 CHECK (luot_xem >= 0),
  ngay_dang TIMESTAMP NOT NULL DEFAULT NOW(),
  id_danh_muc INTEGER NOT NULL REFERENCES danh_muc(id),
  id_nguoi_tao INTEGER NOT NULL REFERENCES nguoi_dung(id)
);

CREATE INDEX chi_muc_bai_viet_danh_muc ON bai_viet (id_danh_muc);
CREATE INDEX chi_muc_bai_viet_moi_nhat ON bai_viet (trang_thai, ngay_dang DESC);

INSERT INTO danh_muc (ten, duong_dan) VALUES
  ('Y khoa', 'y-khoa'),
  ('Dinh dưỡng', 'dinh-duong'),
  ('Sức khoẻ', 'suc-khoe'),
  ('Dược', 'duoc');
