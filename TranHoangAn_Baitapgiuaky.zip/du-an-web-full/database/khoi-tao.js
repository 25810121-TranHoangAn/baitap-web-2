// Chay bang: npm run db:tao
// CANH BAO: se xoa va tao lai cac bang mau. Chi chay khi khoi tao database.
require('dotenv').config();
const fs = require('fs');
const path = require('path');
const bcrypt = require('bcryptjs');
const db = require('../models/db');

const NGUOI_DUNG = [
  { ten: 'admin', matKhau: '123456', hoTen: 'Nguyễn Văn An', vaiTro: 'quan_tri' },
  { ten: 'bientap', matKhau: '123456', hoTen: 'Trần Thị Bình', vaiTro: 'bien_tap_vien' }
];
const DOAN = {
  mo: 'Đây là nội dung minh hoạ cho trang chi tiết tin. Đoạn mở đầu thường nêu bối cảnh: vì sao chủ đề này được quan tâm và nhóm nghiên cứu muốn trả lời câu hỏi gì.',
  thietKe: 'Phần này mô tả đối tượng tham gia, thời gian theo dõi và cách thu thập dữ liệu. Nội dung trong bộ dữ liệu này chỉ dùng minh hoạ giao diện, không đại diện cho một nghiên cứu y khoa có thật.',
  ketQua: 'Phần này minh hoạ cách trình bày phát hiện chính bằng ngôn ngữ dễ hiểu. Khi dùng thật, cần kiểm tra số liệu, khoảng tin cậy và các giới hạn trực tiếp từ bài nghiên cứu gốc.',
  yNghia: 'Phần kết giúp người đọc hiểu kết quả có thể áp dụng đến đâu, đồng thời nhắc rằng một nghiên cứu đơn lẻ chưa đủ để thay đổi thực hành lâm sàng.'
};
const NOI_DUNG = [DOAN.mo, '## Thiết kế nghiên cứu', DOAN.thietKe, '## Kết quả chính', DOAN.ketQua, '## Ý nghĩa thực tế', DOAN.yNghia].join('\n\n');
// [tieu de, tom tat, tap chi minh hoa, id danh muc, so ngay truoc, luot xem, trang thai]
const BAI_VIET = [
  ['Nghiên cứu mới về vai trò của giấc ngủ đối với sức khoẻ tim mạch', 'Bài mẫu minh hoạ cách tóm tắt chủ đề về thời lượng giấc ngủ và sức khoẻ tim mạch; hãy thay bằng nguồn đã kiểm chứng trước khi xuất bản.', 'The Lancet (minh hoạ)', 1, 1, 980, 'da_dang'],
  ['Thử nghiệm lâm sàng giai đoạn III cho thuốc điều trị đái tháo đường mới', 'Bài mẫu giao diện về cách diễn giải kết quả thử nghiệm thuốc; nội dung và kết quả ở đây không phải dữ liệu nghiên cứu thật.', 'NEJM (minh hoạ)', 1, 2, 640, 'da_dang'],
  ['Chế độ ăn Địa Trung Hải và nguy cơ suy giảm trí nhớ ở người lớn tuổi', 'Bài mẫu về dinh dưỡng và trí nhớ, dùng làm dữ liệu thử nghiệm trang danh mục và tìm kiếm.', 'JAMA (minh hoạ)', 2, 3, 870, 'da_dang'],
  ['Đi bộ mỗi ngày bao nhiêu bước là đủ? Phân tích gộp từ nhiều nghiên cứu', 'Bài mẫu để minh hoạ khung phân tích gộp, số lượt xem và trang chi tiết.', 'BMJ (minh hoạ)', 3, 4, 760, 'da_dang'],
  ['Cập nhật khuyến cáo về tương tác giữa thuốc kháng sinh và thực phẩm', 'Bài mẫu giao diện về chủ đề tương tác thuốc - thực phẩm; không thay thế tra cứu hướng dẫn chuyên môn.', 'Nature Medicine (minh hoạ)', 4, 5, 410, 'da_dang'],
  ['Vitamin D và sức khoẻ xương: những điều cần biết sau nghiên cứu mới', 'Bài mẫu chủ đề vitamin D và sức khoẻ xương để kiểm tra phần tìm kiếm, danh mục và bài liên quan.', 'The Lancet (minh hoạ)', 2, 6, 520, 'da_dang'],
  ['Trí tuệ nhân tạo hỗ trợ đọc phim X-quang phổi: kết quả đánh giá thực tế', 'Bài mẫu minh hoạ tin công nghệ y tế và cách trình bày nội dung thành nhiều đoạn.', 'JAMA (minh hoạ)', 1, 7, 455, 'da_dang'],
  ['Căng thẳng kéo dài và hệ miễn dịch: cơ chế mới được mô tả', 'Bài mẫu để kiểm tra bộ lọc danh mục Sức khoẻ và khối Đọc nhiều.', 'Science (minh hoạ)', 3, 8, 300, 'da_dang'],
  ['Vắc-xin thế hệ mới: dữ liệu an toàn từ thử nghiệm quy mô lớn', 'Bài mẫu minh hoạ trình bày thông tin an toàn; không phải báo cáo thử nghiệm thật.', 'NEJM (minh hoạ)', 4, 9, 380, 'da_dang'],
  ['Chất xơ, hệ vi sinh đường ruột và nguy cơ ung thư đại trực tràng', 'Bài mẫu minh hoạ chủ đề dinh dưỡng và hệ vi sinh cho trang tìm kiếm.', 'BMJ (minh hoạ)', 2, 10, 335, 'da_dang'],
  ['Thời gian dùng màn hình và chất lượng giấc ngủ', 'Bài mẫu minh hoạ nội dung sức khoẻ thường thức; hãy thay bằng bài đã được biên tập và kiểm chứng.', 'The Lancet (minh hoạ)', 3, 16, 220, 'da_dang'],
  ['Tác dụng phụ của nhóm thuốc statin: tổng quan mới', 'Bản ghi nháp mẫu để kiểm tra rằng bài chưa xuất bản không xuất hiện trên trang công khai.', 'Nature Medicine (minh hoạ)', 4, 3, 0, 'nhap']
];

async function chay() {
  const sql = fs.readFileSync(path.join(__dirname, 'tao-bang.sql'), 'utf8');
  await db.query(sql);
  console.log('Đã tạo bảng và danh mục.');

  const idNguoi = [];
  for (const n of NGUOI_DUNG) {
    const bam = await bcrypt.hash(n.matKhau, 10);
    const kq = await db.query(
      'INSERT INTO nguoi_dung (ten_dang_nhap, mat_khau_bam, ho_ten, vai_tro) VALUES ($1, $2, $3, $4) RETURNING id',
      [n.ten, bam, n.hoTen, n.vaiTro]
    );
    idNguoi.push(kq.rows[0].id);
  }
  console.log('Đã thêm ' + idNguoi.length + ' người dùng.');

  for (const b of BAI_VIET) {
    await db.query(
      `INSERT INTO bai_viet
       (tieu_de, tom_tat, noi_dung, anh_dai_dien, ten_tap_chi, tieu_de_goc, lien_ket_goc,
        nam_xuat_ban, trang_thai, luot_xem, ngay_dang, id_danh_muc, id_nguoi_tao)
       VALUES ($1, $2, $3, NULL, $4, $5, $6, $7, $8, $9, NOW() - ($10::integer * INTERVAL '1 day'), $11, $12)`,
      [b[0], b[1], NOI_DUNG, b[2], '(Tiêu đề gốc minh hoạ — cần thay bằng dữ liệu thật)', 'https://example.org/', 2026, b[6], b[5], b[4], b[3], idNguoi[0]]
    );
  }
  console.log('Đã thêm ' + BAI_VIET.length + ' bài viết mẫu.');
}

chay()
  .catch((loi) => {
    console.error('LỖI KHỞI TẠO CSDL:', loi.message);
    process.exitCode = 1;
  })
  .finally(async () => {
    await db.end();
  });
