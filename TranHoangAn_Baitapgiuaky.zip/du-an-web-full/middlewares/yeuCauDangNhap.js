// Nguoi gac cong: chi cho qua neu session da co nguoi dung.
module.exports = function yeuCauDangNhap(req, res, next) {
  if (!req.session || !req.session.nguoiDung) {
    return res.redirect('/dang-nhap');
  }
  next();
};
