# MedDigest VN — du-an-web-full

Dự án học tập tích hợp theo 4 tài liệu hướng dẫn: đăng nhập động bằng Express/EJS, cookie + session, mô hình MVC và PostgreSQL/Neon.

## Chức năng

- Trang chủ hiển thị tin nổi bật, tin mới nhất, mục “Đọc nhiều” và menu danh mục đọc từ PostgreSQL.
- Trang danh mục, tìm kiếm, chi tiết bài và bài liên quan đọc từ cơ sở dữ liệu. Lượt xem tăng khi mở bài đã đăng.
- Đăng nhập qua bảng `nguoi_dung`, so sánh mật khẩu bằng `bcryptjs`, session lưu thông tin không chứa mật khẩu.
- Trang quản lý được bảo vệ bằng middleware, có thống kê và CRUD bài viết (thêm/sửa/xoá).
- Truy vấn SQL tham số hoá; kiểm tra dữ liệu tại Controller và dùng ràng buộc của CSDL.
- View dùng EJS, thoát nội dung động bằng `<%= %>`; `404` và `500` có trang riêng.

## Yêu cầu

- Node.js 18 trở lên (khuyến nghị bản LTS đang được hỗ trợ).
- Một PostgreSQL database trên Neon.

## Cài đặt trên Windows / VS Code

1. Giải nén ZIP và mở thư mục `du-an-web-full` trong VS Code.
2. Mở Terminal ngay trong thư mục đó, chạy:

   ```powershell
   npm install
   Copy-Item .env.example .env
   ```

   Nếu dùng Command Prompt thay PowerShell, có thể sao chép `.env.example` thành `.env` bằng File Explorer.

3. Mở `.env`. Dán chuỗi kết nối Neon thật vào `DATABASE_URL` và đổi `SESSION_SECRET` thành chuỗi bí mật riêng. Chuỗi kết nối nên dùng `sslmode=verify-full`. Không gửi file `.env` cho người khác, không đưa lên GitHub.
4. Trong Neon SQL Editor, kiểm tra kết nối bằng `SELECT 1;`.
5. Chạy **một lần khi khởi tạo dữ liệu**:

   ```bash
   npm run db:tao
   ```

   Lệnh này tạo lại 3 bảng và nạp 4 danh mục, 2 tài khoản, 12 bài mẫu. **CẢNH BÁO: script `database/tao-bang.sql` có `DROP TABLE`; chạy lại sẽ xoá dữ liệu hiện tại trong 3 bảng trước khi tạo lại.** Không chạy lại sau khi đã có dữ liệu cần giữ.
6. Khởi động website:

   ```bash
   npm run dev
   ```

7. Mở <http://localhost:3000>.

## Tài khoản mẫu

| Vai trò | Tên đăng nhập | Mật khẩu |
|---|---|---|
| Quản trị | `admin` | `123456` |
| Biên tập viên | `bientap` | `123456` |

Hai tài khoản này chỉ dành cho dữ liệu học tập. Đổi mật khẩu trước khi triển khai công khai; không sử dụng thông tin mặc định trên website thật.

## Đường dẫn chính

- `/` — trang chủ
- `/danh-muc/y-khoa`, `/danh-muc/dinh-duong`, `/danh-muc/suc-khoe`, `/danh-muc/duoc` — danh mục
- `/tim-kiem?q=vitamin` — tìm kiếm
- `/bai-viet/1` — chi tiết bài viết (ID mẫu tuỳ database)
- `/dang-nhap` — đăng nhập
- `/quan-ly` — quản lý (cần đăng nhập)
- `/quan-ly/them` — thêm bài (cần đăng nhập)
- `/dang-xuat` — hành động đăng xuất qua POST; nút ở thanh điều hướng sẽ đăng xuất

## Kiểm thử

```bash
npm run check
```

Sau khi cấu hình Neon và chạy `npm run db:tao`, hãy kiểm thử các luồng: trang chủ/danh mục/chi tiết/tìm kiếm; đăng nhập bỏ trống (400), sai mật khẩu (401), đúng mật khẩu (302 rồi 200); chặn `/quan-ly` khi chưa đăng nhập; thêm/sửa/xoá; mở ID không hợp lệ phải ra 404; dừng và chạy lại máy chủ rồi xác nhận dữ liệu vẫn còn trong PostgreSQL.

## Cấu trúc

```text
du-an-web-full/
├── app.js
├── package.json
├── .env.example
├── database/
│   ├── tao-bang.sql
│   └── khoi-tao.js
├── models/                 # Tầng duy nhất chạy SQL trong ứng dụng
├── controllers/            # Điều phối yêu cầu
├── routes/                 # Ánh xạ đường dẫn
├── middlewares/            # Kiểm tra đăng nhập
├── views/                  # EJS và partials
├── public/css/style.css
└── scripts/kiem-tra-ma.js
```

## Lưu ý

- Session đang dùng MemoryStore mặc định của `express-session`, đúng phạm vi bài thực hành; session sẽ mất khi máy chủ khởi động lại. Không dùng MemoryStore cho hệ thống production cần phiên đăng nhập bền vững.
- Các bài viết trong bộ dữ liệu khởi tạo là **dữ liệu minh hoạ**, không phải tư vấn y tế hay trích dẫn nghiên cứu thật. Thay bằng nguồn đã xác minh trước khi xuất bản thực tế.
- Bản ZIP không chứa `.env`, `node_modules/` hay thông tin Neon thật.
